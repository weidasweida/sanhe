/* ========== i18n ========== */
// Merge products-specific translations into app.js's i18n (prevents const/let redeclaration errors)
(function() {
  const productsZh = {
    "products.home": "商品主页",
    "products.product": "产品管理",
    "products.project": "项目管理",
    "products.package": "套餐管理",
    "products.card": "储值卡管理",
    "products.gift": "积分礼品",
    "products.infoSection": "商品信息",
    "products.configSection": "基础配置",
    "products.type": "产品类型",
    "products.brand": "产品品牌",
    "products.scope": "适用范围",
    "products.spec": "产品规格",
    "products.tag": "自定义标签",
    "products.projectCategory": "项目类别",
    "products.salesUnit": "销售单位",
    "products.roomBed": "房间床位",
    "products.handCard": "手牌管理",
    "products.productName": "产品名称",
    "products.category": "所属类别",
    "products.status": "状态",
    "products.benchmark": "是否标杆",
    "products.position": "适用职位",
    "products.addProduct": "新增产品",
    "products.projectName": "项目名称",
    "products.availableTimes": "可用次数",
    "products.salesPrice": "销售价",
    "products.costPrice": "成本价",
    "products.salesCount": "销量",
    "products.addProject": "新增项目",
    "products.packageName": "套餐名称",
    "products.packageDesc": "套餐说明",
    "products.packageStatus": "套餐状态",
    "products.packageType": "套餐类型",
    "products.validity": "有效期",
    "products.shelfStatus": "上下架",
    "products.addPackage": "新增套餐",
    "products.goodsName": "商品名称",
    "products.cardStatus": "兑换卡状态",
    "products.addCard": "新增兑换卡",
    "products.giftName": "礼品名称",
    "products.requiredPoints": "所需积分",
    "products.giftStock": "库存",
    "products.addGift": "新增礼品",
    "products.allCategories": "全部分类",
    "products.allStatus": "全部状态",
    "products.allScope": "全部适用范围",
    "products.allType": "全部类型",
    "products.allShelf": "全部上下架",
    "products.totalRecords": "共 {total} 条数据",
    "products.totalRecords2": "共 {total} 条数据",
    "products.totalRecords3": "共 {total} 条数据",
    "products.totalRecords4": "共 {total} 条数据",
    "products.totalRecords5": "共 {total} 条数据",
  };
  const productsEn = {
    "products.home": "Home",
    "products.product": "Product",
    "products.project": "Project",
    "products.package": "Packages",
    "products.card": "Cards",
    "products.gift": "Gift Points",
    "products.infoSection": "Product Info",
    "products.configSection": "Basic Config",
    "products.type": "Product Types",
    "products.brand": "Brands",
    "products.scope": "Scope",
    "products.spec": "Specs",
    "products.tag": "Custom Tags",
    "products.projectCategory": "Project Categories",
    "products.salesUnit": "Sale Units",
    "products.roomBed": "Room & Bed",
    "products.handCard": "Hand Cards",
    "products.productName": "Product Name",
    "products.category": "Category",
    "products.status": "Status",
    "products.benchmark": "Benchmark",
    "products.position": "Position",
    "products.addProduct": "Add Product",
    "products.projectName": "Project Name",
    "products.availableTimes": "Available Times",
    "products.salesPrice": "Sales Price",
    "products.costPrice": "Cost Price",
    "products.salesCount": "Sales",
    "products.addProject": "Add Project",
    "products.packageName": "Package Name",
    "products.packageDesc": "Description",
    "products.packageStatus": "Status",
    "products.packageType": "Type",
    "products.validity": "Validity",
    "products.shelfStatus": "Shelf",
    "products.addPackage": "Add Package",
    "products.goodsName": "Goods Name",
    "products.cardStatus": "Card Status",
    "products.addCard": "Add Card",
    "products.giftName": "Gift Name",
    "products.requiredPoints": "Points",
    "products.giftStock": "Stock",
    "products.addGift": "Add Gift",
    "products.allCategories": "All Categories",
    "products.allStatus": "All Status",
    "products.allScope": "All Scope",
    "products.allType": "All Types",
    "products.allShelf": "All Shelf",
    "products.totalRecords": "{total} records",
    "products.totalRecords2": "{total} records",
    "products.totalRecords3": "{total} records",
    "products.totalRecords4": "{total} records",
    "products.totalRecords5": "{total} records",
  };
  Object.assign(i18n.zh, productsZh);
  Object.assign(i18n.en, productsEn);
})();

/* ========== Note ========== */
// currentLang, currentTheme, renderI18n, toggleLang, setTheme, toggleThemePanel, closeThemePanel, navigate
// are all defined in app.js - do not redeclare them here to avoid const/let conflicts

/* ========== Mock Data ========== */
const productList = [
  { name: '瑶浴药包-排毒', spec: '10包/盒', category: '瑶浴系列', status: '启用', scope: '全身', benchmark: '否', brand: '—', position: '—', gift: '—' },
  { name: '瑶浴药包-活血', spec: '10包/盒', category: '瑶浴系列', status: '启用', scope: '全身', benchmark: '是', brand: '—', position: '—', gift: '—' },
  { name: '瑶浴药包-温阳', spec: '10包/盒', category: '瑶浴系列', status: '启用', scope: '全身', benchmark: '否', brand: '—', position: '—', gift: '—' },
  { name: '艾条-纯金艾', spec: '10根/盒', category: '艾条系列', status: '启用', scope: '—', benchmark: '是', brand: '—', position: '—', gift: '—' },
  { name: '艾条-药艾', spec: '10根/盒', category: '艾条系列', status: '启用', scope: '—', benchmark: '否', brand: '—', position: '—', gift: '—' },
  { name: '精油-薰衣草', spec: '100ml', category: '精油系列', status: '启用', scope: '全身', benchmark: '否', brand: '—', position: '—', gift: '是' },
  { name: '精油-茶树', spec: '50ml', category: '精油系列', status: '停用', scope: '局部', benchmark: '否', brand: '—', position: '—', gift: '—' },
  { name: '刮痧板-牛角', spec: '1个', category: '器具', status: '启用', scope: '—', benchmark: '否', brand: '—', position: '—', gift: '是' },
  { name: '拔罐套装-12罐', spec: '1套', category: '器具', status: '启用', scope: '—', benchmark: '否', brand: '—', position: '—', gift: '—' },
  { name: '姜贴-驱寒', spec: '20贴/盒', category: '贴敷系列', status: '启用', scope: '局部', benchmark: '否', brand: '—', position: '—', gift: '—' },
];

const projectList = [
  { name: '大三通', category: '经典项目', times: '不限次', status: '启用', price: '398', cost: '50', sales: '1280' },
  { name: '宫廷理筋', category: '经典项目', times: '1次', status: '启用', price: '298', cost: '30', sales: '856' },
  { name: '脊柱正骨', category: '特色项目', times: '1次', status: '启用', price: '498', cost: '60', sales: '623' },
  { name: '经络推拿', category: '经典项目', times: '1次', status: '启用', price: '268', cost: '25', sales: '432' },
  { name: '火龙罐', category: '特色项目', times: '1次', status: '启用', price: '398', cost: '40', sales: '389' },
  { name: '艾条悬灸', category: '艾灸系列', times: '1次', status: '启用', price: '128', cost: '15', sales: '756' },
  { name: '电针治疗', category: '理疗项目', times: '1次', status: '启用', price: '198', cost: '20', sales: '234' },
  { name: '拔罐', category: '经典项目', times: '1次', status: '启用', price: '68', cost: '8', sales: '1567' },
  { name: '走罐', category: '经典项目', times: '1次', status: '启用', price: '88', cost: '10', sales: '432' },
  { name: '隔姜灸', category: '艾灸系列', times: '1次', status: '停用', price: '168', cost: '25', sales: '198' },
];

const packageList = [
  { name: '经典养生套餐A', desc: '大三通+宫廷理筋+艾灸', price: '698', cost: '200', status: '启用', validity: '6个月', type: '限次套餐' },
  { name: '全身放松套餐B', desc: '经络推拿+拔罐+刮痧', price: '398', cost: '120', status: '启用', validity: '3个月', type: '限次套餐' },
  { name: 'VIP至尊年卡', desc: '全年不限次经典项目', price: '8888', cost: '2000', status: '启用', validity: '12个月', type: '不限次套餐' },
  { name: '季度养生卡', desc: '季度内所有项目8折', price: '2680', cost: '800', status: '启用', validity: '3个月', type: '储值套餐' },
  { name: '肩颈舒缓包', desc: '颈部推拿5次+肩部艾灸3次', price: '598', cost: '180', status: '停用', validity: '6个月', type: '限次套餐' },
  { name: '新客体验套餐', desc: '首次到店体验3项', price: '198', cost: '80', status: '启用', validity: '1个月', type: '限次套餐' },
];

const cardList = [
  { name: '万元兑换卡', validity: '1年', category: '不限制', status: '启用', shelf: '已上架' },
  { name: '5000兑换卡', validity: '1年', category: '不限制', status: '启用', shelf: '已上架' },
  { name: '51000兑换卡', validity: '1年', category: '不限制', status: '启用', shelf: '已上架' },
  { name: '体验卡', validity: '3个月', category: '限制', status: '启用', shelf: '已上架' },
  { name: 'VIP黑金卡', validity: '2年', category: '不限制', status: '停用', shelf: '未上架' },
];

const giftList = [
  { name: '迷你艾灸罐', points: '500', stock: '50', status: '启用' },
  { name: '中药香囊', points: '200', stock: '100', status: '启用' },
  { name: '养生茶包', points: '100', stock: '200', status: '启用' },
  { name: '沐浴球套装', points: '800', stock: '30', status: '启用' },
  { name: '穴位按摩笔', points: '300', stock: '80', status: '停用' },
  { name: '测试商品', points: '1960', stock: '10', status: '启用' },
];

/* ========== Config Mock Data ========== */
const typeList = [
  { name: '畅销系列', sort: 1 },
  { name: '内衣产品系列', sort: 2 },
  { name: '童装系列', sort: 3 },
  { name: '自定义系列', sort: 4 },
];

const brandList = [
  { name: '三合堂', status: '启用' },
  { name: '同仁堂', status: '启用' },
  { name: '云南白药', status: '启用' },
  { name: '片仔癀', status: '启用' },
  { name: '东阿阿胶', status: '启用' },
  { name: '广誉远', status: '启用' },
  { name: '九芝堂', status: '启用' },
  { name: '太极集团', status: '启用' },
  { name: '华润三九', status: '启用' },
  { name: '白云山', status: '启用' },
  { name: '马应龙', status: '停用' },
  { name: '江中', status: '启用' },
  { name: '修正', status: '启用' },
];

const scopeList = [
  { name: '头部', status: '启用' },
  { name: '颈部', status: '启用' },
  { name: '肩部', status: '启用' },
  { name: '背部', status: '启用' },
  { name: '腰部', status: '启用' },
  { name: '腹部', status: '启用' },
  { name: '上肢', status: '启用' },
  { name: '下肢', status: '启用' },
  { name: '全身', status: '启用' },
  { name: '足部', status: '启用' },
  { name: '面部', status: '启用' },
  { name: '眼部', status: '启用' },
  { name: '耳部', status: '启用' },
];

const specList = [
  { name: '10ml', sort: 1 }, { name: '50ml', sort: 2 }, { name: '100ml', sort: 3 },
  { name: '200ml', sort: 4 }, { name: '500ml', sort: 5 }, { name: '5ml', sort: 6 },
  { name: '1盒', sort: 7 }, { name: '5盒', sort: 8 }, { name: '10盒', sort: 9 },
  { name: '1个', sort: 10 }, { name: '1片', sort: 11 }, { name: '5片', sort: 12 },
  { name: '10片', sort: 13 }, { name: '20片', sort: 14 },
  { name: '1套', sort: 15 }, { name: '1双', sort: 16 },
];

const tagList = [
  { name: '热卖', sort: 1 },
  { name: '新品', sort: 2 },
  { name: '限时优惠', sort: 3 },
  { name: '火爆', sort: 4 },
  { name: '畅销', sort: 5 },
  { name: '推荐', sort: 6 },
];

const projectCategoryList = [
  { name: '情趣系列', sort: 1 },
  { name: '内生系列', sort: 2 },
  { name: '经典项目', sort: 3 },
  { name: '特色项目', sort: 4 },
  { name: '艾灸系列', sort: 5 },
  { name: '理疗项目', sort: 6 },
];

const salesUnitList = [
  { name: '个' }, { name: '盒' }, { name: '包' }, { name: '瓶' },
  { name: '支' }, { name: '套' }, { name: '双' }, { name: '片' }, { name: '贴' },
];

const roomBedList = [
  { room: '101房', old: '否', group: 'A组', store: '三合堂001店' },
  { room: '102房', old: '是', group: 'A组', store: '三合堂001店' },
  { room: '103房', old: '否', group: 'B组', store: '三合堂001店' },
];

const handCardList = [];
for (let i = 1; i <= 10; i++) {
  handCardList.push({ code: `sh${String(i).padStart(2,'0')}`, store: '三合900店' });
}

/* ========== Init ========== */
function initProducts() {
  switchProductTab('home');
}

/* ========== Tab Switching ========== */
function switchProductTab(tabName) {
  // Update sidebar sub-nav-item highlight
  document.querySelectorAll('.sidebar .sub-nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.tab === tabName);
  });
  document.querySelectorAll('.p-tab-content').forEach(el => {
    el.classList.toggle('active', el.dataset.tab === tabName);
  });

  switch(tabName) {
    case 'home': break;
    case 'product': renderProductTable(); break;
    case 'project': renderProjectTable(); break;
    case 'package': renderPackageTable(); break;
    case 'card': renderCardTable(); break;
    case 'gift': renderGiftTable(); break;
    case 'type': renderTypeTable(); break;
    case 'brand': renderBrandTable(); break;
    case 'scope': renderScopeTable(); break;
    case 'spec': renderSpecTable(); break;
    case 'tag': renderTagTable(); break;
    case 'project-category': renderProjectCategoryTable(); break;
    case 'sales-unit': renderSalesUnitTable(); break;
    case 'room-bed': renderRoomBedTable(); break;
    case 'hand-card': renderHandCardTable(); break;
  }
}

/* ========== Render Product Table ========== */
function renderProductTable() {
  const tbody = document.getElementById('productTableBody');
  tbody.innerHTML = productList.map(p => `
    <tr>
      <td><input type="checkbox" /></td>
      <td>${p.name}</td>
      <td>${p.spec}</td>
      <td>${p.category}</td>
      <td><span class="p-tag ${p.status === '启用' ? 'enabled' : 'disabled'}">${p.status}</span></td>
      <td>${p.scope || '—'}</td>
      <td>${p.benchmark === '是' ? '<span class="p-tag benchmark">是</span>' : '—'}</td>
      <td>${p.brand || '—'}</td>
      <td>${p.position || '—'}</td>
      <td>${p.gift || '—'}</td>
      <td>
        <span class="p-action-link" onclick="showToast('修改产品')">修改</span>
        <span class="p-action-link danger" onclick="showToast('删除产品')">删除</span>
      </td>
    </tr>
  `).join('');
}

/* ========== Render Project Table ========== */
function renderProjectTable() {
  const tbody = document.getElementById('projectTableBody');
  tbody.innerHTML = projectList.map(p => `
    <tr>
      <td><input type="checkbox" /></td>
      <td>${p.name}</td>
      <td>${p.category}</td>
      <td>${p.times}</td>
      <td><span class="p-tag ${p.status === '启用' ? 'enabled' : 'disabled'}">${p.status}</span></td>
      <td>¥${p.price}</td>
      <td>¥${p.cost}</td>
      <td>${p.sales}</td>
      <td>
        <span class="p-action-link" onclick="showToast('修改项目')">修改</span>
        <span class="p-action-link danger" onclick="showToast('删除项目')">删除</span>
      </td>
    </tr>
  `).join('');
}

/* ========== Render Package Table ========== */
function renderPackageTable() {
  const tbody = document.getElementById('packageTableBody');
  tbody.innerHTML = packageList.map(p => `
    <tr>
      <td><input type="checkbox" /></td>
      <td>${p.name}</td>
      <td>${p.desc}</td>
      <td>¥${p.price}</td>
      <td>¥${p.cost}</td>
      <td><span class="p-tag ${p.status === '启用' ? 'enabled' : 'disabled'}">${p.status}</span></td>
      <td>${p.validity}</td>
      <td>${p.type}</td>
      <td><span class="p-tag ${p.status === '启用' ? 'sold' : 'unsold'}">${p.status === '启用' ? '已上架' : '未上架'}</span></td>
      <td>
        <span class="p-action-link" onclick="showToast('修改套餐')">修改</span>
        <span class="p-action-link danger" onclick="showToast('删除套餐')">删除</span>
      </td>
    </tr>
  `).join('');
}

/* ========== Render Card Table ========== */
function renderCardTable() {
  const tbody = document.getElementById('cardTableBody');
  tbody.innerHTML = cardList.map(c => `
    <tr>
      <td><input type="checkbox" /></td>
      <td>${c.name}</td>
      <td>${c.validity}</td>
      <td>${c.category}</td>
      <td><span class="p-tag ${c.status === '启用' ? 'enabled' : 'disabled'}">${c.status}</span></td>
      <td><span class="p-tag ${c.shelf === '已上架' ? 'sold' : 'unsold'}">${c.shelf}</span></td>
      <td>
        <span class="p-action-link" onclick="showToast('修改兑换卡')">修改</span>
        <span class="p-action-link danger" onclick="showToast('删除兑换卡')">删除</span>
      </td>
    </tr>
  `).join('');
}

/* ========== Render Gift Table ========== */
function renderGiftTable() {
  const tbody = document.getElementById('giftTableBody');
  tbody.innerHTML = giftList.map(g => `
    <tr>
      <td><input type="checkbox" /></td>
      <td>${g.name}</td>
      <td>${g.points}</td>
      <td>${g.stock}</td>
      <td><span class="p-tag ${g.status === '启用' ? 'enabled' : 'disabled'}">${g.status}</span></td>
      <td>
        <span class="p-action-link" onclick="showToast('修改礼品')">修改</span>
        <span class="p-action-link danger" onclick="showToast('删除礼品')">删除</span>
      </td>
    </tr>
  `).join('');
}

/* ========== Render Config Tables ========== */
function renderTypeTable() {
  document.getElementById('typeTableBody').innerHTML = typeList.map(t =>
    `<tr><td><input type="checkbox" /></td><td>${t.name}</td><td>${t.sort}</td><td><span class="p-action-link" onclick="showToast('修改产品类型')">修改</span><span class="p-action-link danger" onclick="showToast('删除产品类型')">删除</span></td></tr>`
  ).join('');
}
function renderBrandTable() {
  document.getElementById('brandTableBody').innerHTML = brandList.map(b =>
    `<tr><td><input type="checkbox" /></td><td>${b.name}</td><td><span class="p-tag ${b.status === '启用' ? 'enabled' : 'disabled'}">${b.status}</span></td><td><span class="p-action-link" onclick="showToast('修改品牌')">修改</span><span class="p-action-link danger" onclick="showToast('删除品牌')">删除</span></td></tr>`
  ).join('');
}
function renderScopeTable() {
  document.getElementById('scopeTableBody').innerHTML = scopeList.map(s =>
    `<tr><td><input type="checkbox" /></td><td>${s.name}</td><td><span class="p-tag ${s.status === '启用' ? 'enabled' : 'disabled'}">${s.status}</span></td><td><span class="p-action-link" onclick="showToast('修改部位')">修改</span><span class="p-action-link danger" onclick="showToast('删除部位')">删除</span></td></tr>`
  ).join('');
}
function renderSpecTable() {
  document.getElementById('specTableBody').innerHTML = specList.map(s =>
    `<tr><td><input type="checkbox" /></td><td>${s.name}</td><td>${s.sort}</td><td><span class="p-action-link" onclick="showToast('修改规格')">修改</span><span class="p-action-link danger" onclick="showToast('删除规格')">删除</span></td></tr>`
  ).join('');
}
function renderTagTable() {
  document.getElementById('tagTableBody').innerHTML = tagList.map(t =>
    `<tr><td><input type="checkbox" /></td><td>${t.name}</td><td>${t.sort}</td><td><span class="p-action-link" onclick="showToast('修改标签')">修改</span><span class="p-action-link danger" onclick="showToast('删除标签')">删除</span></td></tr>`
  ).join('');
}
function renderProjectCategoryTable() {
  document.getElementById('projectCategoryTableBody').innerHTML = projectCategoryList.map(c =>
    `<tr><td><input type="checkbox" /></td><td>${c.name}</td><td>${c.sort}</td><td><span class="p-action-link" onclick="showToast('修改分类')">修改</span><span class="p-action-link danger" onclick="showToast('删除分类')">删除</span></td></tr>`
  ).join('');
}
function renderSalesUnitTable() {
  document.getElementById('salesUnitTableBody').innerHTML = salesUnitList.map(u =>
    `<tr><td><input type="checkbox" /></td><td>${u.name}</td><td><span class="p-action-link" onclick="showToast('修改单位')">修改</span><span class="p-action-link danger" onclick="showToast('删除单位')">删除</span></td></tr>`
  ).join('');
}
function renderRoomBedTable() {
  document.getElementById('roomBedTableBody').innerHTML = roomBedList.map(r =>
    `<tr><td><input type="checkbox" /></td><td>${r.room}</td><td>${r.old}</td><td>${r.group}</td><td>${r.store}</td><td><span class="p-action-link" onclick="showToast('修改房间')">修改</span><span class="p-action-link danger" onclick="showToast('删除房间')">删除</span></td></tr>`
  ).join('');
}
function renderHandCardTable() {
  document.getElementById('handCardTableBody').innerHTML = handCardList.map((c, i) =>
    `<tr><td><input type="checkbox" /></td><td>${i + 1}</td><td>${c.code}</td><td>${c.store}</td><td><span class="p-action-link" onclick="showToast('修改手牌')">修改</span><span class="p-action-link danger" onclick="showToast('删除手牌')">删除</span></td></tr>`
  ).join('');
}

/* ========== Toast ========== */
function showToast(msg, type = 'info') {
  const existing = document.querySelector('.p-toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.className = 'p-toast';
  toast.style.cssText = `
    position: fixed; top: 80px; left: 50%; transform: translateX(-50%);
    background: var(--color-primary); color: #fff; padding: 10px 20px;
    border-radius: 8px; font-size: 14px; font-weight: 500; z-index: 9999;
    box-shadow: 0 4px 16px rgba(0,0,0,0.2);
  `;
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 2000);
}

/* ========== Init ========== */
document.addEventListener('DOMContentLoaded', initProducts);
